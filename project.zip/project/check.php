<form>
	<input type="password" name="abc" pattern="[a-z]+" required>
	<input type="submit" name="abc">
</form>
<script type="text/javascript">
	
	function check() {
		let a = 10;
		let c = "abc";
		let b = 10;
		let d = 10;
		
		let ab = a + c + b + d;
		alert(ab);		
	}
	check();

</script>