<?php
	$server = 'localhost';
	$user = 'root';
	$password = '';
	$db = "auction";
	$con = mysqli_connect($server,$user,$password,$db) or die ("Database connection Problem Occured!");
?>